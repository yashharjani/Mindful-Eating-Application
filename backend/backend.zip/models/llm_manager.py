# import os
# import torch
# import joblib
# import numpy as np
# from torch import nn
# from typing import Dict

# # ========== TIP GENERATOR (SmolLM) ==========
# from transformers import AutoTokenizer, AutoModelForCausalLM, AutoModel, AutoConfig

# # Model locations (edit if you use different folders)
# TIPS_MODEL_DIR = os.getenv("TIPS_MODEL_DIR", "models/smollm-lora-final")
# TRAIT_SCALER_PATH = os.getenv("TRAIT_SCALER_PATH", "models/trait_scaler.pkl")
# TRAIT_CLASSIFIER_PATH = os.getenv("TRAIT_CLASSIFIER_PATH", "models/dominant_classifier_sentence_mlp.pt")

# # --------- Load Tip model (SmolLM) ----------
# _tip_tokenizer = None
# _tip_model = None

# def _load_tip_model():
#     global _tip_tokenizer, _tip_model
#     if _tip_model is None:
#         _tip_tokenizer = AutoTokenizer.from_pretrained(TIPS_MODEL_DIR)
#         _tip_model = AutoModelForCausalLM.from_pretrained(
#             TIPS_MODEL_DIR, torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
#         )
#         _tip_model = _tip_model.to("cuda" if torch.cuda.is_available() else "cpu")

# def generate_tip(trait: str, behavior_text: str) -> str:
#     """
#     Generate a short, personalized mindful-eating tip using your fine-tuned SmolLM.
#     """
#     _load_tip_model()
#     # prompt = (
#     #     "Generate a short, personalized mindful eating tip.\n"
#     #     f"Dominant Trait: {trait}\n"
#     #     f"Eating Behavior: {behavior_text}\n"
#     #     "Tip:"
#     # )
#     prompt = (
#         f"### Instruction:\n"
#         f"Generate a short, personalized mindful eating tip based on the user's dominant trait and selected eating behavior.\n\n"
#         f"### Input:\n"
#         f"Dominant Trait: {trait}\n"
#         f"Eating Behavior: {behavior_text}\n\n"
#         f"### Response:\nTip:"
#     )
#     inputs = _tip_tokenizer(prompt, return_tensors="pt").to(_tip_model.device)
#     with torch.no_grad():
#         out = _tip_model.generate(
#             **inputs,
#             max_new_tokens=70,
#             temperature=0.7,
#             do_sample=True,
#             pad_token_id=_tip_tokenizer.eos_token_id,
#         )
#     text = _tip_tokenizer.decode(out[0], skip_special_tokens=True)
#     # Return only what comes after "Tip:"
#     return text.split("Tip:")[-1].strip()


# # ========== DOMINANT TRAIT CLASSIFIER (MLP over sentence embedding) ==========

# # Simple MLP head you trained (adjust dims if your head differs)
# class MLPClassifier(nn.Module):
#     def __init__(self, input_size=384, num_classes=5):
#         super().__init__()
#         self.fc1 = nn.Linear(input_size, 256)
#         self.relu = nn.ReLU()
#         self.fc2 = nn.Linear(256, num_classes)

#     def forward(self, x):
#         x = self.relu(self.fc1(x))
#         return self.fc2(x)

# # Load scaler + classifier
# _scaler = None
# _trait_model = None

# def _load_trait_head():
#     global _scaler, _trait_model
#     if _trait_model is None:
#         _scaler = joblib.load(TRAIT_SCALER_PATH)
#         _trait_model = MLPClassifier()
#         state = torch.load(TRAIT_CLASSIFIER_PATH, map_location="cpu")
#         _trait_model.load_state_dict(state)
#         _trait_model.eval()

# # ========== Text Embedding (Sentence Transformer) ==========
# # Uses all-MiniLM-L6-v2 (384-dim). Install: pip install sentence-transformers
# _embedder = None

# def _load_embedder():
#     global _embedder
#     if _embedder is None:
#         from sentence_transformers import SentenceTransformer
#         _embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# def get_sentence_embedding(text: str) -> np.ndarray:
#     _load_embedder()
#     emb = _embedder.encode([text], normalize_embeddings=False)  # shape (1, 384)
#     return emb  # numpy array

# def predict_big_five_scores(input_text: str) -> Dict[str, float]:
#     """
#     Return a dict of 5 scores in [0,1] for the Big Five.
#     We use your MLP head over a sentence embedding of the compiled user info.
#     """
#     _load_trait_head()
#     emb = get_sentence_embedding(input_text)            # (1, 384)
#     emb_scaled = _scaler.transform(emb)                 # scale
#     with torch.no_grad():
#         logits = _trait_model(torch.tensor(emb_scaled, dtype=torch.float32))  # (1,5)
#         probs = torch.softmax(logits, dim=1).cpu().numpy()[0]

#     traits = ["extraversion", "agreeableness", "conscientiousness", "neuroticism", "openness"]
#     return {t: float(p) for t, p in zip(traits, probs)}

# def predict_dominant_trait_from_text(input_text: str) -> str:
#     scores = predict_big_five_scores(input_text)
#     return max(scores, key=scores.get)

# import os
# import torch
# import joblib
# import numpy as np
# import torch.nn as nn
# import torch.nn.functional as F
# from typing import Dict
# from sentence_transformers import SentenceTransformer
# from transformers import AutoTokenizer, AutoModelForCausalLM
# from peft import PeftModel   # ✅ for LoRA adapter loading
# import logging

# # Configure logging
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s - %(levelname)s - %(message)s",
# )
# logger = logging.getLogger(__name__)


# # =============================== #
# #        PATH CONFIGURATIONS      #
# # =============================== #

# # Base + adapter locations
# BASE_MODEL = os.getenv("BASE_MODEL", "HuggingFaceTB/SmolLM-1.7B-Instruct")
# TIPS_MODEL_DIR = os.getenv("TIPS_MODEL_DIR", "models/smollm-lora-final")
# TRAIT_SCALER_PATH = os.getenv("TRAIT_SCALER_PATH", "models/trait_scaler.pkl")
# TRAIT_CLASSIFIER_PATH = os.getenv("TRAIT_CLASSIFIER_PATH", "models/dominant_classifier_sentence_mlp.pt")

# device = "cuda" if torch.cuda.is_available() else "cpu"


# # =============================== #
# #        TIP GENERATOR (SmolLM)   #
# # =============================== #

# _tip_tokenizer = None
# _tip_model = None
# MODEL_PRELOADED = False

# def _load_tip_model():
#     """Load SmolLM base + LoRA adapter for tip generation."""
#     global _tip_tokenizer, _tip_model
#     if _tip_model is None:
#         print(f"🔹 Loading base model: {BASE_MODEL}")
#         _tip_tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)

#         # Load base model
#         base_model = AutoModelForCausalLM.from_pretrained(
#             BASE_MODEL,
#             torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
#         )

#         # Apply LoRA adapter
#         print(f"🔹 Applying LoRA adapter from: {TIPS_MODEL_DIR}")
#         _tip_model = PeftModel.from_pretrained(base_model, TIPS_MODEL_DIR)
#         _tip_model = _tip_model.to(device)
#         _tip_model.eval()
#         print("✅ SmolLM (LoRA) tip model loaded successfully.")


# def preload_all_models():
#     global MODEL_PRELOADED
#     if MODEL_PRELOADED:
#         return
    
#     _load_embedder()
#     _load_trait_model()
#     _load_tip_model()

#     MODEL_PRELOADED = True
#     logger.info("🔥 All LLM models loaded & ready.")

# def generate_tip(trait: str, behavior_text: str) -> str:
#     """
#     Generate a short, personalized mindful eating tip using the fine-tuned SmolLM LoRA adapter.
#     """
#     # _load_tip_model()

#     prompt = (
#         f"### Instruction:\n"
#         f"Generate a short, personalized mindful eating tip based on the user's dominant trait and selected eating behavior.\n\n"
#         f"### Input:\n"
#         f"Dominant Trait: {trait}\n"
#         f"Eating Behavior: {behavior_text}\n\n"
#         f"### Response:\nTip:"
#     )

#     inputs = _tip_tokenizer(prompt, return_tensors="pt").to(device)
#     with torch.no_grad():
#         outputs = _tip_model.generate(
#             **inputs,
#             max_new_tokens=80,
#             temperature=0.7,
#             top_p=0.9,
#             do_sample=True,
#             pad_token_id=_tip_tokenizer.eos_token_id,
#         )

#     decoded = _tip_tokenizer.decode(outputs[0], skip_special_tokens=True)
#     logger.info(f"=== Decoded value : {decoded} ===")
#     if "Tip:" in decoded:
#         decoded = decoded.split("Tip:", 1)[-1].strip()
#         decoded = "Tip: " + decoded.split("###")[0].strip()
#     return decoded


# # =============================== #
# #   DOMINANT TRAIT PREDICTOR (MLP)
# # =============================== #

# class MLPClassifier(nn.Module):
#     """Same architecture used during your training."""
#     def __init__(self, in_dim=389, hidden=256, num_classes=5):
#         super().__init__()
#         self.net = nn.Sequential(
#             nn.Linear(in_dim, hidden),
#             nn.ReLU(),
#             nn.Dropout(0.3),
#             nn.Linear(hidden, 128),
#             nn.ReLU(),
#             nn.Dropout(0.2),
#             nn.Linear(128, num_classes)
#         )

#     def forward(self, x):
#         return self.net(x)


# # --- Lazy loading ---
# _embedder = None
# _scaler = None
# _trait_model = None

# def _load_embedder():
#     global _embedder
#     if _embedder is None:
#         _embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L12-v2")

# def _load_trait_model():
#     global _scaler, _trait_model
#     if _trait_model is None:
#         _scaler = joblib.load(TRAIT_SCALER_PATH)
#         _trait_model = MLPClassifier(in_dim=389).to(device)
#         state = torch.load(TRAIT_CLASSIFIER_PATH, map_location=device)
#         _trait_model.load_state_dict(state)
#         _trait_model.eval()


# LABELS = ["openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"]
# DOMINANT_MAP = {
#     0: "Openness",
#     1: "Conscientiousness",
#     2: "Extraversion",
#     3: "Agreeableness",
#     4: "Neuroticism",
# }


# def predict_dominant_trait(text: str, raw_traits: np.ndarray = None) -> Dict[str, Dict]:
#     """Predict dominant Big Five trait using fine-tuned MLP classifier."""
#     _load_embedder()
#     _load_trait_model()

#     if raw_traits is None:
#         raw_traits = np.array([0.5, 0.5, 0.5, 0.5, 0.5])

#     text_emb = _embedder.encode([text], convert_to_numpy=True)
#     traits_scaled = _scaler.transform([raw_traits])
#     X = np.hstack((text_emb, traits_scaled))  # shape (1, 389)

#     with torch.no_grad():
#         X_tensor = torch.tensor(X, dtype=torch.float32).to(device)
#         logits = _trait_model(X_tensor)
#         probs = F.softmax(logits, dim=1).cpu().numpy().flatten()

#     scores = {LABELS[i]: float(round(probs[i], 3)) for i in range(len(LABELS))}
#     dominant_idx = int(np.argmax(probs))
#     dominant_trait = DOMINANT_MAP[dominant_idx]

#     return {"dominant_trait": dominant_trait, "trait_scores": scores}


# def get_sentence_embedding(text: str) -> np.ndarray:
#     _load_embedder()
#     return _embedder.encode([text], convert_to_numpy=True)


# def predict_dominant_trait_from_text(input_text: str) -> str:
#     result = predict_dominant_trait(input_text)
#     return result["dominant_trait"]

import os
import torch
import joblib
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import logging
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_MODEL = "HuggingFaceTB/SmolLM-1.7B-Instruct"
TIPS_MODEL_DIR = "models/smollm-lora-final"
TRAIT_SCALER_PATH = "models/trait_scaler.pkl"
TRAIT_CLASSIFIER_PATH = "models/dominant_classifier_sentence_mlp.pt"

device = "cuda" if torch.cuda.is_available() else "cpu"

MODEL_PRELOADED = False   # 🔥 IMPORTANT GLOBAL FLAG

_tip_tokenizer = None
_tip_model = None

_embedder = None
_scaler = None
_trait_model = None


# ---------------- WAIT FOR PRELOAD ----------------
def wait_until_models_ready():
    """Block until preload_all_models() has completed."""
    global MODEL_PRELOADED
    while not MODEL_PRELOADED:
        logger.info("⏳ Waiting for models to finish loading...")
        time.sleep(1)


# ---------------- TIP MODEL (LoRA) ----------------
def _load_tip_model():
    global _tip_tokenizer, _tip_model

    if _tip_model is not None:
        return

    logger.info(f"🔹 Loading base SmolLM: {BASE_MODEL}")

    _tip_tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)

    base = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    )

    logger.info(f"🔹 Applying LoRA from {TIPS_MODEL_DIR}")

    _tip_model = PeftModel.from_pretrained(base, TIPS_MODEL_DIR)
    _tip_model = _tip_model.to(device)
    _tip_model.eval()

    logger.info("✅ SmolLM LoRA loaded.")


# ---------------- PERSONALITY PREDICTOR ----------------
class MLPClassifier(nn.Module):
    def __init__(self, in_dim=389, hidden=256, num_classes=5):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes),
        )

    def forward(self, x):
        return self.net(x)


def _load_embedder():
    global _embedder
    if _embedder is None:
        _embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L12-v2")


def _load_trait_model():
    global _trait_model, _scaler

    if _trait_model is None:
        _scaler = joblib.load(TRAIT_SCALER_PATH)
        _trait_model = MLPClassifier(389).to(device)
        state = torch.load(TRAIT_CLASSIFIER_PATH, map_location=device)
        _trait_model.load_state_dict(state)
        _trait_model.eval()


# ---------------- PRELOAD ALL ----------------
def preload_all_models():
    """
    Called ONCE at server startup.
    Ensures all models are ready before any API call.
    """
    global MODEL_PRELOADED

    if MODEL_PRELOADED:
        return

    logger.info("🔥 Loading embedder...")
    _load_embedder()

    logger.info("🔥 Loading trait model...")
    _load_trait_model()

    logger.info("🔥 Loading tip generator...")
    _load_tip_model()

    MODEL_PRELOADED = True
    logger.info("🎉 ALL MODELS ARE READY 🎉")


# ---------------- TIP GENERATION ----------------
def generate_tip(trait: str, behavior_text: str) -> str:
    wait_until_models_ready()   # 🔥 critical

    prompt = f"""
        ### Instruction:
        Generate a short personalized mindful eating tip.

        ### Input:
        Dominant Trait: {trait}
        Eating Behavior: {behavior_text}

        ### Response:
        Tip:
    """

    inputs = _tip_tokenizer(prompt, return_tensors="pt").to(device)

    with torch.no_grad():
        outputs = _tip_model.generate(
            **inputs,
            max_new_tokens=80,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
            pad_token_id=_tip_tokenizer.eos_token_id,
        )

    decoded = _tip_tokenizer.decode(outputs[0], skip_special_tokens=True)

    if "Tip:" in decoded:
        decoded = decoded.split("Tip:", 1)[-1].strip()

    return "Tip: " + decoded


# ---------------- PERSONALITY PREDICTION ----------------
LABELS = ["openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"]
DOMINANT_MAP = {
    0: "Openness",
    1: "Conscientiousness",
    2: "Extraversion",
    3: "Agreeableness",
    4: "Neuroticism",
}


def predict_dominant_trait(text: str, raw_traits=None):
    wait_until_models_ready()

    if raw_traits is None:
        raw_traits = np.array([0.5] * 5)

    emb = _embedder.encode([text], convert_to_numpy=True)
    scaled = _scaler.transform([raw_traits])
    X = np.hstack((emb, scaled))

    with torch.no_grad():
        logits = _trait_model(torch.tensor(X, dtype=torch.float32).to(device))
        probs = F.softmax(logits, dim=1).cpu().numpy().flatten()

    idx = int(np.argmax(probs))

    return {
        "dominant_trait": DOMINANT_MAP[idx],
        "trait_scores": {LABELS[i]: float(probs[i]) for i in range(5)}
    }