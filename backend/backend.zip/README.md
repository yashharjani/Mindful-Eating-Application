# Mindful Eating Backend

## Overview
The **Mindful Eating Backend** is a Python-based backend application designed to help users manage their eating habits by setting daily goals, providing personalized tips, and tracking their progress. Built with FastAPI, it offers a robust and scalable infrastructure for managing user data, generating insights, and delivering personalized recommendations.

## Features
- **User Goal Management**: Allows users to create, update, and retrieve daily eating goals.
- **Personalized Tips**: Generates custom recommendations based on user data and behavioral traits.
- **Questionnaire Submissions**: Captures user responses to questionnaires to better understand user needs.
- **Authentication and Authorization**: Secure user access via token-based authentication.
- **Database Integration**: Uses SQLAlchemy and PostgreSQL for data storage and management.

## Technologies Used
- **Python** (95.8% of the codebase)
- **FastAPI**: A modern web framework for building APIs.
- **SQLAlchemy**: Database ORM for managing relational data.
- **Alembic**: Database migrations.
- **Pydantic**: Data validation and settings management.
- **Gunicorn**: WSGI server for production.

## File Structure
- `app/controllers`: Contains logic for interacting with user goals, tips, and questionnaires.
- `app/routes`: Defines API endpoints for user interaction.
- `migrations`: Database migration scripts.
- `requirements.txt`: Lists all dependencies required to run the project.

## Setup and Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/samshad/mindful-eating-backend.git
   cd mindful-eating-backend
   ```
2. Set up a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Configure environment variables:
   - Create a `.env` file in the project root.
   - Add the necessary environment variables (e.g., database URL, API keys).
5. Run the database migrations:
   ```bash
   alembic upgrade head
   ```
6. Start the development server:
   ```bash
   uvicorn app.main:app --reload
   ```

## API Endpoints
Outlined below are a few key endpoints:
- POST `/submit-user-goal`: Submits or updates the user's daily goal.
- GET `/get-user-goal`: Retrieves the current day's user goal.
- POST `/submit-user-tips`: Submits personalized tips for the user.
- GET `/get-user-tips`: Fetches tips for the current day.
- GET `/question-list`: Lists available questionnaires.
- POST `/submit-answers`: Submits user responses to questionnaires.

For a complete list of endpoints, refer to the [FastAPI Documentation](http://127.0.0.1:8000/docs) after starting the server.

## Contribution Guidelines
Contributions are welcome! Please follow these steps:
1. Fork the repository and create a new branch.
2. Make your changes and test thoroughly.
3. Submit a pull request with a clear description of the changes.

## License
This project does not yet specify a license. Ensure compliance with the repository's terms before contributing.

