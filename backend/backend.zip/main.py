# from fastapi import FastAPI
# from app.routes import user, question, food_update, behavior, goal, tips, big_five
# from fastapi.middleware.cors import CORSMiddleware

# app = FastAPI()

# # app.add_middleware(
# #     CORSMiddleware,
# #     allow_origins=["*"],  # Replace with specific origins in production
# #     allow_credentials=True,
# #     allow_methods=["*"],
# #     allow_headers=["*"],
# # )

# origins = [
#     "http://localhost:8081",   # Expo web
#     "http://localhost:8082",   # Expo web alternative
#     "http://192.168.2.16:8082", # your local dev server
#     "http://192.168.2.16:19006", # Expo Go local tunnel
#     "http://192.168.2.16",      # your backend IP
#     "exp://192.168.2.16:8082"   # Expo dev app
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,         # Or use ["*"] for testing
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# app.include_router(user.router, prefix="/auth", tags=["Authentication"])
# app.include_router(question.router, prefix="/question", tags=["question"])
# app.include_router(behavior.router, prefix="/behavior", tags=["behavior"])
# app.include_router(goal.router, prefix="/goal", tags=["goal"])
# app.include_router(tips.router, prefix="/tips", tags=["tips"])
# app.include_router(food_update.router, prefix="/food-update", tags=["food_update"])
# app.include_router(big_five.router, prefix="/big-five", tags=["big_five"])


# @app.get("/")
# def root():
#     return {"message": "API is running!"}


# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware
# import asyncio
# import logging

# # Import routes
# from app.routes import user, question, food_update, behavior, goal, tips, big_five

# # Import the heavy model manager (SmolLM + MLP)
# from models import llm_manager

# # Configure logging
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s - %(levelname)s - %(message)s",
# )
# logger = logging.getLogger(__name__)

# # Initialize FastAPI app
# app = FastAPI(title="Mindful Eating Backend", version="1.0")

# # ---------------- CORS CONFIG ----------------
# origins = [
#     "http://localhost:8081",      # Expo web
#     "http://localhost:8082",      # Expo web alt
#     "http://192.168.2.16:8082",   # Local dev
#     "http://192.168.2.16:19006",  # Expo Go local tunnel
#     "http://192.168.2.16",        # Local backend IP
#     "exp://192.168.2.16:8082"     # Expo dev app
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # Or ["*"] during testing
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # ---------------- ROUTES ----------------
# app.include_router(user.router, prefix="/auth", tags=["Authentication"])
# app.include_router(question.router, prefix="/question", tags=["Question"])
# app.include_router(behavior.router, prefix="/behavior", tags=["Behavior"])
# app.include_router(goal.router, prefix="/goal", tags=["Goal"])
# app.include_router(tips.router, prefix="/tips", tags=["Tips"])
# app.include_router(food_update.router, prefix="/food-update", tags=["Food Update"])
# app.include_router(big_five.router, prefix="/big-five", tags=["Big Five Traits"])

# # ---------------- ROOT ----------------
# @app.get("/")
# def root():
#     return {"message": "API is running and healthy 🚀"}


# # ---------------- MODEL PRELOAD ----------------
# @app.on_event("startup")
# async def preload_models():
#     """
#     Preload heavy ML models (SmolLM + SentenceTransformer + MLP)
#     once at app startup to avoid delays on user login or dashboard.
#     """
#     logger.info("🚀 Starting model preloading...")
#     try:
#         loop = asyncio.get_event_loop()
#         await loop.run_in_executor(None, llm_manager._load_tip_model)
#         await loop.run_in_executor(None, llm_manager._load_embedder)
#         await loop.run_in_executor(None, llm_manager._load_trait_model)
#         logger.info("✅ All models preloaded successfully.")
#     except Exception as e:
#         logger.error(f"⚠️ Model preload failed: {e}")

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import asyncio
import logging

# Routes
from app.routes import user, question, food_update, behavior, goal, tips, big_five

# Model preload manager
from models import llm_manager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

app = FastAPI(title="Mindful Eating Backend", version="1.0")

# CORS
origins = [
    "http://localhost:8081",
    "http://localhost:8082",
    "http://192.168.2.16:8082",
    "http://192.168.2.16:19006",
    "http://192.168.2.16",
    "exp://192.168.2.16:8082"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(user.router, prefix="/auth", tags=["Authentication"])
app.include_router(question.router, prefix="/question", tags=["Question"])
app.include_router(behavior.router, prefix="/behavior", tags=["Behavior"])
app.include_router(goal.router, prefix="/goal", tags=["Goal"])
app.include_router(tips.router, prefix="/tips", tags=["Tips"])
app.include_router(food_update.router, prefix="/food-update", tags=["Food Update"])
app.include_router(big_five.router, prefix="/big-five", tags=["Big Five Traits"])


@app.get("/")
def root():
    return {"message": "API is running 🚀"}


@app.on_event("startup")
async def preload_models():
    """Load heavy models BEFORE dashboard or login is hit."""
    logger.info("🚀 Preloading models...")

    try:
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, llm_manager.preload_all_models)

        logger.info("✅ All models preloaded successfully.")

    except Exception as e:
        logger.error(f"❌ Model preload failed: {e}")